function Customer(name,acno,bal){
this.name=name;
var Accountno=acno;
var balance=bal;
Object.defineProperty(this, "Account"  ,{
get:function(){
    return Accountno
}}),
Object.defineProperty(this,"newbalance",{
    get:function(){
        return balance
    },
    set:function(value){
        if(1000<balance)
            return balance=value
        else{
            console.log("low balance")
        }    
    }
}
    )
}
   
let obj1=new Customer("Ankit","SBI123",25000)
obj1.newbalance-=6000

console.log(obj1.name,obj1.Account,obj1.newbalance)